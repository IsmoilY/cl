package uz.etaom.order;

public class TestOrderApplication {
}
