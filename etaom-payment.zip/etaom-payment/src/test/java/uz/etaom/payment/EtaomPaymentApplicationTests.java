package uz.etaom.payment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtaomPaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
