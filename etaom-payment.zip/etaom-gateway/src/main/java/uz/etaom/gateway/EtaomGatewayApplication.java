package uz.etaom.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtaomGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtaomGatewayApplication.class, args);
	}

}
